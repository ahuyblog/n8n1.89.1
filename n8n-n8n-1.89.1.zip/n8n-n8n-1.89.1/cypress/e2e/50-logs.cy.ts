describe('Logs', () => {
	// TODO: the test can be written without AI nodes once https://linear.app/n8n/issue/SUG-39 is implemented
	it('should open NDV with the run index that corresponds to clicked log entry');
});
